// Scott Fitzgerald
// Assignment #2
// Status: Completed
// Date: 2020-06-02

// Takes user inputs for dollar amount and USD -> euro conversion rate. Converts 
// Calculates the conversion and displays the converted amount in euros

#include <iostream>
#include <iomanip>
using namespace std;

// Function prototypes for getting and processing data
// Pass by reference since we have mutiple variables
void getData(double&, double&);
void processData(double&, double&, double&);
// Can pass by value to display results since we don't need to return anything
void displayResults(double dollarAmount, double euroAmount);

int main()
{
	// Declarations
	double dollarAmount, conversionRate, euroAmount;

	// Get and process the dollar amount and conversion rate, display resutls
	getData(dollarAmount, conversionRate);
	processData(dollarAmount, conversionRate, euroAmount);
	displayResults(dollarAmount, euroAmount);

	return 0;
}

void getData(double &dollarAmount, double &conversionRate)
{
	// Get user input for dollar amt and conversion rate
	// Store results in variables defined in main()
	cout << "\nThis program converts dollars to euros." << endl;
	cout << "Enter an dollar amount: ";
	cin >> dollarAmount;
	cout << "Enter a conversion rate: ";
	cin >> conversionRate;
}

void processData(double &dollarAmount, double &conversionRate, double &euroAmount)
{
	// Perform the conversion, store results in euroAmount in main()
	euroAmount = dollarAmount * conversionRate;
}

void displayResults(double dollarAmount, double euroAmount)
{
	// Display results, limited to two decimal places
	cout << fixed << setprecision (2);
	cout << "Dollar amount: $" << dollarAmount << endl;
	cout << "Euro amount: $" << euroAmount << endl;
}