// Scott Fitzgerald
// Assignment #3
// Status: Completed
// Date: 2020-06-02

// Calculates the sales tax and the total sales amount for a transaction, provided the sale amount 
// and tax rate.

#include <iostream>
#include <iomanip>
using namespace std;

// Function prototypes for getting and processing data 
// pass by reference since we have to update mutiple variables
void getData(double&, double&);
void processData(double&, double&, double&, double&);
// Can pass by value to displayResults() since we don't need to return anything
void displayResults(double saleAmount, double salesTax, double totalSalesAmount);

int main()
{
	// Takes sale amount and tax rate as user input. Calculates and displays the pre-tax sale amount, 
	// the sales tax and the total sales amount

	// Declarations
	double saleAmount;        // user-provided sale amount   
	double taxRate;           // user-provided tax rate
	double salesTax;          // used to store sales tax amount calculation
	double totalSalesAmount;  // // used to store total sales amount calculation

	// Get user input, process the calculation, and display the results
	getData(saleAmount, taxRate);
	processData(saleAmount, taxRate, salesTax, totalSalesAmount);
	displayResults(saleAmount, salesTax, totalSalesAmount);

	return 0;
}

void getData(double &saleAmount, double &taxRate)
{
	// Get user input for sale amt and tax rate, store results in variables defined in main()
	cout << "\nThis program calculates the sales tax and sales figure for a transaction." << endl;
	cout << "\nEnter the sale amount in dollars: $";
	cin >> saleAmount;
	cout << "Enter the tax rate as a whole number with decimals (e.g. 8.25): ";
	cin >> taxRate;
	
}

void processData(double &saleAmount, double &taxRate, double &salesTax, double &totalSalesAmount)
{
	// Calculate tax amount and total amount, store results in variables in main()
	salesTax = (taxRate / 100) * saleAmount;
	totalSalesAmount = saleAmount * (1 + (taxRate / 100));	
}

void displayResults(double saleAmount, double salesTax, double totalSalesAmount)
{
	// Display results, limited to two decimal places
	cout << fixed << setprecision (2);
	cout << "\nThe sale amount is: $ " << saleAmount << endl;
	cout << "The sales tax is: $ " << salesTax << endl;
	cout << "The total amount is: $ " << totalSalesAmount << endl;
}