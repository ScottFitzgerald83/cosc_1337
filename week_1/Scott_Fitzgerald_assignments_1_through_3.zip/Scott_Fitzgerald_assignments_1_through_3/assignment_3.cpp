// Scott Fitzgerald
// Assignment #3
// Status: Completed
// Date: 2020-06-02

// Calculates the sales tax and the total sales amount for a transaction, provided the sale amount 
// and tax rate.


#include <iostream>
using namespace std;

int main()
{
	// Takes sale amount and tax rate as user input. Calculates and displays the pre-tax sale amount, 
	// the sales tax and the total sales amount

	// Declarations
	double saleAmount;        // user-provided sale amount   
	double taxRate;           // user-provided tax rate
	double salesTax;          // used to store sales tax amount calculation
	double totalSalesAmount;  // // used to store total sales amount calculation

	// Get user input for sale amount and tax rate
	cout << "\nThis program calculates the sales tax and sales figure for a transaction." << endl;
	cout << "\nEnter the sale amount in dollars: $";
	cin >> saleAmount;
	cout << "Enter the tax rate as a whole number with decimals (e.g. 8.25): ";
	cin >> taxRate;

	// Calculate sales tax and total sale amount
	salesTax = (taxRate / 100) * saleAmount;
	totalSalesAmount = saleAmount * (1 + (taxRate / 100));

	// Display results
	cout << "\nThe sale amount is: $ " << saleAmount << endl;
	cout << "The sales tax is: $ " << salesTax << endl;
	cout << "The total amount is: $ " << totalSalesAmount << endl;

	return 0;
}
