// Scott Fitzgerald
// Assignment #2
// Status: Completed
// Date: 2020-06-02

// Takes user inputs for dollar amount and USD -> euro conversion rate. Converts 
// Calculates the conversion and displays the converted amount in euros

#include <iostream>
using namespace std;

int main()
{
	// Takes a user-provided USD amount, converts to euros, and displays the result
	
	// Declarations
	double dollarAmount;    // user-provided dollar amount  
	double conversionRate;  // user-provided conversion rate   
	double euroAmount;      // used to store USD -> euro calculation

	// Get user input for dollar amt and conversion rate
	cout << "\nThis program converts dollars to euros." << endl;
	cout << "Enter a dollar amount: $";
	cin >> dollarAmount;
	cout << "Enter the conversion rate as a decimal (e.g., .93): ";
	cin >> conversionRate;

	// Calculate euros
	euroAmount = dollarAmount * conversionRate;

	// Display the results
	cout << "Dollar amount: $" << dollarAmount << endl;
	cout << "Euro amount: $" << euroAmount << endl;
	
	return 0;
}


